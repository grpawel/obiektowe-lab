package agh.cs.lab;

public enum MoveDirection {
    Forward,
    Backward,
    Right,
    Left
}
